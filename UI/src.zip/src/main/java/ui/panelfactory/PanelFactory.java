package ui.panelfactory;

import ui.home.HomeUI;

public class PanelFactory {
	
	public PanelFactory(HomeUI frame){
		
	}

}
